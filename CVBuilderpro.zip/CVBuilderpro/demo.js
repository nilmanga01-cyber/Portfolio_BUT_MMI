const form = document.getElementById("cvForm");
const preview = document.getElementById("cvPreview");
const photoInput = document.getElementById("photo");
let photoUrl = "";

const value = (id) => document.getElementById(id).value.trim();
const escapeHtml = (text) => text.replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[character]));
const lines = (text) => escapeHtml(text).replace(/\n/g, "<br>");

function renderCv() {
    const name = value("name") || "Nom Prénom";
    const job = value("job") || "Titre du poste";
    const contact = [value("location"), value("email"), value("phone")].filter(Boolean);
    const sections = [
        ["Profil professionnel", value("profile")],
        ["Expérience professionnelle", value("experience")],
        ["Formation", value("education")],
        ["Compétences", value("skills")],
        ["Langues", value("languages")]
    ].filter(([, content]) => content);

    preview.innerHTML = `
        <article class="cv-sheet">
            <header class="cv-top">
                ${photoUrl ? `<img class="cv-photo" src="${photoUrl}" alt="Photo de ${escapeHtml(name)}">` : ""}
                <div><h1>${escapeHtml(name)}</h1><p class="cv-job">${escapeHtml(job)}</p></div>
            </header>
            <p class="cv-contact">${contact.length ? contact.map(escapeHtml).join(" <span>•</span> ") : "Ville · email@example.com · 06 00 00 00 00"}</p>
        ${sections.map(([title, content]) => `<div class="cv-section"><h2>${title}</h2><p>${lines(content)}</p></div>`).join("") || `<p class="cv-hint">Remplissez le formulaire pour voir apparaître les rubriques de votre CV.</p>`}
        </article>`;
}

form.addEventListener("input", renderCv);
form.addEventListener("submit", (event) => {
    event.preventDefault();
    renderCv();
    document.querySelector(".preview-area").scrollIntoView({ behavior: "smooth", block: "start" });
});
form.addEventListener("reset", () => {
    if (photoUrl) URL.revokeObjectURL(photoUrl);
    photoUrl = "";
    setTimeout(renderCv, 0);
});
photoInput.addEventListener("change", () => {
    if (photoUrl) URL.revokeObjectURL(photoUrl);
    const file = photoInput.files[0];
    photoUrl = file ? URL.createObjectURL(file) : "";
    renderCv();
});
document.getElementById("printCv").addEventListener("click", () => window.print());
renderCv();
